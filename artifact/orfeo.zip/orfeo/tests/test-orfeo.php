<?php
/**
 * Class TestOrfeo
 *
 * @package Orfeo
 */
/**
 * Sample test case.
 */
class TestOrfeo extends WP_UnitTestCase {
	/**
	 * A single example test.
	 */
	function test_generic() {
		// Replace this with some actual testing code.
		$this->assertTrue( defined( 'ORFEO_VERSION' ) );
	}
}
